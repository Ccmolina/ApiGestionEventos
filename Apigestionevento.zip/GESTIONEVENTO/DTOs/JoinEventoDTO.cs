public class JoinEventDTO
{
    public int EventoId { get; set; }
}