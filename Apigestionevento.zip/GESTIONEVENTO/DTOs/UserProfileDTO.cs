public class UpdateUserProfileDTO
{
    public string Username { get; set; }
    public string Email { get; set; }
}